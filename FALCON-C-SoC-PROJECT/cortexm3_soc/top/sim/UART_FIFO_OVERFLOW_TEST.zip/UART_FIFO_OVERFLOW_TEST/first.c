#include <stdint.h>

#define read_addr(addr)       (*(volatile uint32_t *)addr)
#define write_addr(addr, val) ((*(volatile uint32_t *)addr) = (val))

#define SRAM_A_base_ADDR (uint32_t)(0x00000000)
#define debug_reg0       (uint32_t *)(SRAM_A_base_ADDR + 0x0FF0)

// UART Base & Offsets
#define UART_BASE 0x40002000
#define UART_THR  (UART_BASE + 0x00) // Transmit Holding
#define UART_DLL  (UART_BASE + 0x00) // Divisor Latch LSB
#define UART_DLM  (UART_BASE + 0x01) // Divisor Latch MSB
#define UART_FCR  (UART_BASE + 0x02) // FIFO Control
#define UART_LCR  (UART_BASE + 0x03) // Line Control
#define UART_MCR  (UART_BASE + 0x04) // Modem Control
#define UART_LSR  (UART_BASE + 0x05) // Line Status

int main () 
{ 
    uint32_t lsr_status;

    // Test start
    write_addr(debug_reg0, 0x00000001);
 
    // 1. Correct Initialization (DLAB = Bit 7)
    write_addr(UART_LCR, 0x00000080); // Enable DLAB
    write_addr(UART_DLM, 0x00000000); 
    write_addr(UART_DLL, 0x00000007); 
    write_addr(UART_LCR, 0x00000003); // Disable DLAB, Set 8-bit word

    // 2. Enable FIFOs (Bit 0) and Clear TX/RX FIFOs (Bits 1 & 2)
    write_addr(UART_FCR, 0x00000007); 

    // 3. Enable Internal Loopback (Bit 4 of MCR)
    // This forces everything we transmit to bounce immediately into the RX FIFO
    write_addr(UART_MCR, 0x00000010);

    // 4. THE OVERFLOW STRIKE
    // The FIFO is 16 bytes deep. We deliberately blast 18 bytes into it.
    for(int j = 0; j < 18; j++) {
        write_addr(UART_THR, 0xAA); 
    }
    
    // 5. Hardware Delay (Volatile prevents compiler from deleting it)
    // Gives the UART time to physically shift the bits in loopback
    for(volatile int i = 0; i < 500; i++);
    
    // 6. Verification: Check the Line Status Register
    lsr_status = read_addr(UART_LSR);

    // Bit 1 is the Overrun Error (OE) flag. 
    // Mask the register (lsr_status & 0x02) to isolate Bit 1.
    if ((lsr_status & 0x02) == 0x02) {
        // OVERFLOW DETECTED: Hardware works! Signal Pass to UVM.
        write_addr(debug_reg0, 0x00000007); 
    } else {
        // OVERFLOW MISSED: Hardware failed. Signal Error to UVM.
        write_addr(debug_reg0, 0x0000000E); 
    }
    for(int i=0;i<100;i++){
		}
    // Safe trap
    while(1);
}